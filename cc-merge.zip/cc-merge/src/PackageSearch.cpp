#include "PackageSearch.h"

#include <QProcess>
#include <QFile>
#include <QTextStream>

PackageSearch::PackageSearch(QObject *parent)
    : QAbstractListModel(parent)
{
    QFile f("/usr/share/raku-kris/owned-packages.txt");
    if (f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&f);
        while (!in.atEnd()) {
            const QString line = in.readLine().trimmed();
            if (!line.isEmpty())
                m_owned << line;
        }
    }
}

int PackageSearch::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : m_results.size();
}

QVariant PackageSearch::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_results.size())
        return {};

    const Entry &e = m_results.at(index.row());
    switch (role) {
    case NameRole:      return e.name;
    case SummaryRole:   return e.summary;
    case InstalledRole: return e.installed;
    case OwnedRole:     return e.owned;
    default:            return {};
    }
}

QHash<int, QByteArray> PackageSearch::roleNames() const
{
    return {
        {NameRole, "name"},
        {SummaryRole, "summary"},
        {InstalledRole, "installed"},
        {OwnedRole, "owned"},
    };
}

void PackageSearch::search(const QString &term)
{
    const QString t = term.trimmed();
    if (t.size() < 2)
        return;

    m_installed.clear();
    QProcess rpm;
    rpm.start("rpm", {"-qa", "--qf", "%{NAME}\n"});
    rpm.waitForFinished(30000);
    for (const QByteArray &l : rpm.readAllStandardOutput().split('\n')) {
        if (!l.isEmpty())
            m_installed << QString::fromUtf8(l);
    }

    QProcess q;
    q.start("dnf5", {"repoquery", "--available", "--search", t,
                     "--queryformat", "%{name}\t%{summary}"});
    q.waitForFinished(90000);
    const QString out = QString::fromUtf8(q.readAllStandardOutput());

    beginResetModel();
    m_results.clear();
    QSet<QString> seen;
    const auto lines = out.split('\n');
    for (const QString &line : lines) {
        const int tab = line.indexOf('\t');
        const QString name = (tab < 0 ? line : line.left(tab)).trimmed();
        if (name.isEmpty() || seen.contains(name))
            continue;
        seen.insert(name);
        Entry e;
        e.name = name;
        e.summary = (tab < 0 ? "" : line.mid(tab + 1)).simplified().left(512);
        e.installed = m_installed.contains(name);
        e.owned = m_owned.contains(name);
        m_results << e;
        if (m_results.size() >= 200)
            break;
    }
    endResetModel();
    emit searchFinished();
}
